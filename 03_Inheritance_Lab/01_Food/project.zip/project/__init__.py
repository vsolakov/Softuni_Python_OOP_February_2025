from project.food import Food
from project.fruit import Fruit