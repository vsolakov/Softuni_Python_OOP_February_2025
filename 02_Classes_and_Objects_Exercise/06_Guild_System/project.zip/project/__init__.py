from project.player import Player
from project.guild import Guild