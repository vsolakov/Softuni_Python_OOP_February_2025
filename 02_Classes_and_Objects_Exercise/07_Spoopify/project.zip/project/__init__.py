from project.album import Album
from project.song import Song
from project.band import Band