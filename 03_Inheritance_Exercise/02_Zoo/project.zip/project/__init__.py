from project.animal import Animal
